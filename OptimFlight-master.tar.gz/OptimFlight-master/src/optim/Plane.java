package optim;

import java.util.ArrayList;

public class Plane {
	ArrayList<Flight> flights;
	
	public Plane() {
		this.flights = new ArrayList<Flight>();
	}

	public boolean affect(Flight flight) {
		
		// if  we can affect ,we affect 
		if (checkAffect(flight))
		{
			this.flights.add(flight);
			return true;
		}
		
		
		
		return false;
	}

	private boolean checkAffect(Flight flight) {
		// TODO Auto-generated method stub
		boolean checkEmpty=flights.isEmpty();
		boolean checkAiport=this.flights.get(flights.size()-1).equals(flight.getAirport_departure());
		boolean checkDay=this.flights.get(flights.size()-1).getDay()<=flight.getDay();
		
		if (this.flights.get(flights.size()-1).getDay()==flight.getDay()) {
			if (this.flights.get(flights.size()-1).getUtc_arrival_time()<=flight.getUtc_departure_time()) {
				checkDay=true;
			}

		}
				
				
		if (checkEmpty ||(checkAiport && )
		
		return false;
	}
	
}
